import pygame
import sys
import math
import mapHandler
import asyncio


cachingSystem = {}  
thisDrone = 0
path = []
class drone:
    def __init__(self):
        self.size = pygame.Vector2(60, 60)
        self.image = pygame.transform.scale(pygame.image.load("assets/droneShip.png").convert_alpha(), (self.size.x, self.size.y)) 
        self.idle = True
        self.position = pygame.Vector2(500, 300)
        self.rotation = 0
        global thisDrone
        thisDrone = self

    def move(self):
        global path
        if (not self.idle):    
            if (len(path) >= 0):
                myNode = path[0]
                if myNode.get("start") != self.position or not (myNode.get("start").x - 10 < (self.position).x and myNode.get("start").y + 10 > (self.position).y):
                    self.position = self.position + myNode.get("moveVec")
                else:
                    del myNode
            if len(path) == 0:
                self.idle = True
                path.clear()
            

    def buildNewPath(self, target):
        global path
        global cachingSystem
        self.idle = True
        path.clear()
        cachingSystem.clear()
        cachingSystem["S1-"] = {"start": self.position, "current": self.position, "moveVec": (target - self.position).normalize(), "goal": target, "name": "S1-", "locked": False, "tick": 0, "success": False, "type": "goal", "focus": 1}

    def tickForward(self): 
        global path
        global cachingSystem
        carryK, carryV = 0, 0
        for key, val in list(cachingSystem.items()):
            if (not val.get("locked")):
                val["current"] = val.get("current") + val.get("moveVec")
                if (val.get("current").x > 1280 or  val.get("current").x < 0 or val.get("current").y < 0 or val.get("current").x > 600):
                    val["locked"] = True
                val["tick"] = val.get("tick")+1
                if (val.get("tick") % 25 == 0):
                    if val.get("type") == "goal": # make it perpindicular
                        cachingSystem[key, val.get("focus"), "R-"] = {"start": val.get("current"), "current": val.get("current"), "moveVec": pygame.Vector2(val.get("moveVec").y, -val.get("moveVec").x), "goal": val.get("goal"), "name": str(key) + str(val.get("focus")) + "R-", "locked": False, "tick": 0, "success": False, "type": "perp", "focus": 1}
                        # go to right, last one was left
                        cachingSystem[key, val.get("focus"), "L-"] = {"start": val.get("current"), "current": val.get("current"), "moveVec": pygame.Vector2(-val.get("moveVec").y, val.get("moveVec").x), "goal": val.get("goal"), "name": str(key) + str(val.get("focus")) + "L-", "locked": False, "tick": 0, "success": False, "type": "perp", "focus": 1}
                    else:
                        cachingSystem[key, val.get("focus"), "T-"] = {"start": val.get("current"), "current": val.get("current"), "moveVec": (val.get("goal") - val.get("current")).normalize(), "goal": val.get("goal"), "name": (str(key) + str(val.get("focus")) + "T-"), "locked": False, "tick": 0, "success": False, "type": "goal", "focus": 1}
                    val["focus"] = val.get("focus") + 1
                for key1, val1 in mapHandler.objects.items():
                    if (val1.rect.collidepoint(val.get("current"))):
                        val["locked"] = True
                        break

                val1 = mapHandler.cakes.sprites()[0]
                if (val1.rect.collidepoint(val.get("current"))):
                    val["locked"] = True
                    val["success"] = True
                    carryK = key
                    carryV = val
                    break
                    
                if (val.get("goal").x - 20 < val.get("current").x and val.get("current").x < val.get("goal").x + 20) and (val.get("goal").y - 20 < val.get("current").y and val.get("current").y < val.get("goal").y + 20):
                    val["locked"] = True
                    val["success"] = True
                    carryK = key
                    carryV = val
                    break
        if carryV != 0:
            if carryV.get("success"):
                for i in range(3, len(carryK)+1, 3):
                    sendToList = cachingSystem.get(carryK[0:i])
                    print(sendToList)
                    path.append(sendToList)
                self.idle = False
                cachingSystem.clear()