import pygame
import sys
import asyncio
import random
import mapHandler
import drone

async def main():
    pygame.init()

    clock = pygame.time.Clock()

    width = 1280
    length = 600
    screen = pygame.display.set_mode((width, length))
    pygame.display.set_caption("Atef's Cupcake Collector")

    plr = mapHandler.mapObject("player", pygame.image.load("assets/jsabFriend.png").convert_alpha(), {"spawnVec": pygame.Vector2(width/2, length/2), "sizeX": 75, "sizeY": 75, "center": pygame.Vector2((width+100)/2, (length+100)/2)})
    mapHandler.mapObject("ground", pygame.image.load("assets/mariograss.png").convert_alpha(), {"spawnVec": pygame.Vector2(0, 500), "sizeX": 1280, "sizeY": 100})
    mapHandler.mapObject("platform1", pygame.image.load("assets/mariograss.png").convert_alpha(), {"spawnVec": pygame.Vector2(400, 200), "sizeX": 200, "sizeY": 20})
    mapHandler.mapObject("platform2", pygame.image.load("assets/mariograss.png").convert_alpha(), {"spawnVec": pygame.Vector2(100, 300), "sizeX": 100, "sizeY": 20})

    def makeCake():
        made = False
        while not made:
            newlyBaked = mapHandler.mapObject("cupcake", pygame.image.load("assets/cupcake.png").convert_alpha(), {"spawnVec": pygame.Vector2(random.randint(100, width-100), random.randint(50, 450)), "sizeX": 100, "sizeY": 100})
            touch = pygame.sprite.spritecollide(newlyBaked, mapHandler.playerCols, False)
            if len(touch) > 0: newlyBaked.kill()
            else: made = True

    grass = (10, 161, 58)


    dragging = False
    moving = pygame.Vector2(0,0)
    shift = pygame.Vector2(0,0)

    myDrone = drone.drone()

    playerGrav = 0
    grounded = False
    running = True
    makeCake()
    while running:
        myDrone.tickForward()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 3:
                    x, y = event.pos
                    myDrone.buildNewPath(pygame.Vector2(x, y))
                if event.button == 1:
                    dragging = True
                    for key, val in mapHandler.objects.items():
                        if (val.rect.collidepoint(pygame.mouse.get_pos())):
                            moving = val.rect
                            break
                    vec2 = pygame.Vector2(pygame.mouse.get_pos())
                    shift = pygame.Vector2(val.rect.x - vec2.x, val.rect.y - vec2.y)
            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    dragging = False
                    shift, moving = pygame.Vector2(0,0), pygame.Vector2(0,0)
            if event.type == pygame.MOUSEMOTION:
                if (dragging == True):
                    vec2 = pygame.Vector2(pygame.mouse.get_pos())
                    moving.x = vec2.x + shift.x
                    moving.y = vec2.y + shift.y


        keys = pygame.key.get_pressed()
        if (grounded and (keys[pygame.K_SPACE])): 
            playerGrav = -20
            grounded = False
        if (keys[pygame.K_LEFT] or keys[pygame.K_a]): mapHandler.objects.get("player").rect.x = mapHandler.objects.get("player").rect.x + -5
        if (keys[pygame.K_RIGHT] or keys[pygame.K_d]): mapHandler.objects.get("player").rect.x = mapHandler.objects.get("player").rect.x + 5
        
        if not grounded:
            mapHandler.objects.get("player").rect.y = mapHandler.objects.get("player").rect.y + playerGrav
            playerGrav += 1

        grounded = False # i know this seems dumb but it just resets grounded just incase the player moves off
        touch = pygame.sprite.spritecollide(plr, mapHandler.playerCols, False)
        grabbed = pygame.sprite.spritecollide(plr, mapHandler.cakes, True)
        for cup in grabbed: makeCake()


        for block in touch:
            if playerGrav > 0:
                plr.rect.bottom = block.rect.top
                playerGrav = 0
                grounded = True
            elif playerGrav < 0:  
                plr.rect.top = block.rect.bottom
                playerGrav = 0
            
        mapHandler.loadScreen(screen)
        myDrone.move()
        screen.blit(myDrone.image, myDrone.position)
        pygame.display.flip()
        clock.tick(120)
        await asyncio.sleep(0)
asyncio.run(main())
